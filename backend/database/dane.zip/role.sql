INSERT INTO role (role_name) VALUES ('moderator');
INSERT INTO role (role_name) VALUES ('administrator');
