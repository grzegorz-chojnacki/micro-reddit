INSERT INTO survey (question, post_id) VALUES ('Which recent news story is the most interesting?', 9);
INSERT INTO survey (question, post_id) VALUES ('What is your favorite number?', 20);
INSERT INTO survey (question, post_id) VALUES ('What was your favorite restaurant when you were a child? ', 25);
