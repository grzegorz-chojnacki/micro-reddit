INSERT INTO survey_answer (answer, survey_id) VALUES ('COVID-19', 1);
INSERT INTO survey_answer (answer, survey_id) VALUES ('Exams', 1);
INSERT INTO survey_answer (answer, survey_id) VALUES ('5', 2);
INSERT INTO survey_answer (answer, survey_id) VALUES ('10', 2);
INSERT INTO survey_answer (answer, survey_id) VALUES ('12', 2);
INSERT INTO survey_answer (answer, survey_id) VALUES ('McDonalds', 3);
INSERT INTO survey_answer (answer, survey_id) VALUES ('Pizza Hut', 3);
INSERT INTO survey_answer (answer, survey_id) VALUES ('KFC', 3);
INSERT INTO survey_answer (answer, survey_id) VALUES ('Burger King', 3);
